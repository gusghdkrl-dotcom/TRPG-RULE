# 정본·경험 연속성·저장·복원

규칙판: 생존 호러 안정화판 2026-11-17. 정확한 배포 식별자는 RULESET.json. 상시 서사·묘사는 프로젝트 지침, 상황별 조회는 00-index.md. 필요한 절만 읽는다.

## STATE_AUTHORITY

적용: 실제 정본/저장/복원. 현재 확정 진행은 작업 상태에, 영속 진행 정본은 Supabase verified history에 둔다. 신규 기본은 Supabase 비공개 정본 원문+DOCUMENT_BOUND(DB1) 누적 동적 체크포인트다. 정확한 정본 .md 원본 파일도 소유자에게 전달해 프로젝트 소스에 보관하게 한다. GitHub 세이브/미러는 생성하지 않는다. 외부 차단 자체를 해결하는 기능이나 별도 영구 메모리를 이 문서가 만들지는 않는다.
현행 대상은 trpg-state-v2 / project ref taoaffdyssqtnjszumpq / public.gm_checkpoint_history의 verified history 및 원문 state_json이다. 이 신규 DB에는 gm_sessions 최신 미러를 만들지 않았으며 verified history가 유일한 정상 복원 정본이다. 최초 연결/실제 변경 때 공개 데이터 API가 아닌 인증된 권한 있는 Supabase 연결과 trpg_v2_commit/verify/load_version/load/list/inspect_pending의 실제 계약을 확인한다. 확인한 계약은 같은 조건에서 재사용한다.
인증된 연결을 사용하고 키를 출력하지 않는다. 일반 판정/NPC 대화에 DB를 호출하지 않는다. 필요한 값이 현재 상태에 있으면 사용한다. 저장 완료는 실제 verify+동일 version read-back 뒤에만 표시한다. 차단·검증 실패는 STATE_SAVE_FAILURE_CONTINUE로 처리하며 운영 테이블/함수/권한/외부 앱을 임의 변경하지 않는다.

## PRIVATE_CANON_DOCUMENT

이 절은 **설계의 저장 위치·원문 검증**을 담당한다. 세계 생성 내용/합격 기준은 04-setup SCENARIO_BLUEPRINT/COMPATIBILITY_GATE 한 곳을 따른다. 설계를 여기에 중복 규정하지 않는다. 기존 정본의 다음 **10개 절** 안에 정식 entity/ref로 연결한다.

| 절 | 저장할 정본 내용 |
|---|---|
| CANON_INDEX | session/campaign·규칙 배포 식별자·정본 판본·원작 출처와 절/정식 ref 색인 |
| WORLD_BASELINE | 원작의 정확한 단위/확인 출처·시대·사회/생활·최초 불가역 G·공식 사실/각색/미확인 구별 |
| HIDDEN_TRUTH | 원작 중심 원인·실제 선행 사건/행위·최종 대응에 필요한 핵심 사실·알기 전후 대응/대가의 차이 |
| WORLD_RULES | 적/환경/초자연의 실제 감각·능력/제약·HP/기능/공격·피해식·SAN 적격 노출·회피/방호/약점/중단·한 존재의 복수 위협 형태 |
| NPC_BASELINES | 유한 초기 인물/적 ID·위치/이동·능력/장비/자원·실제 지식/모르는 것·생활/과거/관계/목적·목소리 예시·거절/합의/동행/이탈과 PC 부재 시 다음 행동 |
| LOCATION_BASELINES | 넓은 생활 지도/시설·정식 하위 방 ID와 별칭·실제 출입/경로/거리·소요/통신·소유 실물/사적 기록·엄폐/퇴로/안전·누가 언제 감지하는지 |
| EVIDENCE_BASELINES | 사전 확정된 실제 원문/발췌·날짜/표식/작성자/소유·실물 수량/탄약/위치·공식 원본/각색 구별·복수 발견 경로와 알게 되는 사실 |
| DRIVER_BASELINES | E별 고유 위기/선행 인과·발동/차단·위기 자체를 보장할 독립 예비 원인/실행자·정보/위치/수단/물리 소요·전원 현장 접근 경로·성공/부분/실패/미개입과 후속 영향. 유한 조건부 적 풀의 프로필/근원/공급 상한/동시 활동 한도/발동/중단·실재 개체 생성 ID. 독립 S/생활·우발 만남 유한 후보/적격 조건·자율 여파 |
| ENDING_CONDITIONS | 모든 E의 전원 현장 체험 후 최종 국면·실제 최종 대응자의 진실 이해/실행·최종 봉쇄/해제/탈출 시련·완전/부분 성취·전멸/불가역 실패·실제 동료/자원/관계가 바꾸는 결과 |
| PC_CONNECTIONS | 각 PC의 확정 생활/직업/관계·원래 말투/습관/실제 과거 사례·현재 위치/일/목적/지식·G로 위태로운 구체 대상·숨은 인과/진실 발견과 여러 실제 현장 접근·즉시 가능한 선택 |

원격 기여는 E 체험으로 인정하지 않으며 모든 참가 PC가 각 E를 현장에서 직접 체험한다. 세계 E의 발생/해결과 PC별 지식·체험·수락은 별개로 기록한다. E 위기는 반드시 발생하도록 미리 독립 인과를 준비하지만 PC의 이동/수락·판정·부상/광기·사망을 대본으로 확정하지 않는다. 죽거나 제압된 개체의 손실·피해 0·국지 안전은 동적 상태에서 보존한다. 남은 E가 있는 최종 국면은 설계 실패다. 새 서버 컬럼·추가 정본 절·새 영구 저장소는 만들지 않는다.

**정본 생성/전달/등록:** 같은 전체 UTF-8 원문으로 키퍼용 비공개 `PRIVATE_CANON_<campaign_id>_r<revision>.md` 원본 파일을 소유자에게 전달하고, Supabase 비공개 `trpg_private.gm_canon_documents`에 저장한다. 소유자는 원래 파일을 프로젝트 소스로 보관한다. 업로드를 기다리느라 DB 저장을 미루지 않는다. 공개 GitHub/게임 지문/HUD에 비공개 원문을 노출하지 않는다. 원문 SHA-256과 실제 저장된 동일 판본 전체 read-back을 대조해야 verified다. 파일 전달·DB 저장·read-back 검증·프로젝트 업로드는 각각의 실제 결과로 구별하며 하나의 성공을 다른 성공으로 꾸미지 않는다. 정본 검증 후 setup_bootstrap 체크포인트는 STATE_COMMIT의 commit→verify→동일버전 read-back으로 잇는다.

**판본·누적 변화:** 규칙판/정본 판본·원문 SHA는 STATE_CANON_SAVE_BINDING으로 체크포인트와 일치시킨다. 최초 사실은 정본, 이후 PC/NPC/적의 실제 반응·위치/소유·생사·사건 처리와 경험은 누적 world_delta/STATE_WORKING_CONTEXT다. 최초 정본으로 최신 상태를 덮거나 이미 처리한 E/S/난수를 재생하지 않는다. 중요한 정본 오류는 근거·변경 범위를 명시한 새 판본으로만 보완하며 구판 verified 원문/해시·손실/안전·구판 시간표/종결을 재작성하지 않는다. 재개는 신규 생성이 아니다. 실제 저장 실패는 STATE_SAVE_FAILURE_CONTINUE/STATE_RECOVERY로 처리한다.

## PRIVATE_CANON_ACCESS_ROUTER

필요한 실제 사실 → 현재 작업 상태 → Supabase에 검증된 해당 campaign/canon/revision 비공개 정본의 절/entity → checkpoint 순서로 확인한다. 동일 판본을 이미 조회했으면 재사용한다. 프로젝트 .md는 동일 원문을 보존하는 소유자용 파일/복구 자료다. NPC는 현재 기억+해당 baseline, 단서는 현재 소유/발견+원문, 법칙/위협은 현재 발동/차단+능력, 공간은 현재 경로+지도, 시간 진행은 활성 원인 색인+관련 조건, 종결은 실제 결과+ENDING_CONDITIONS를 쓴다.
campaign_id+canon_id+revision+절/entity ID로 조회하고, 현재 확인 가능한 같은 본문이 있으면 재조회하지 않는다. 룰북 절차와 실제 캠페인 사실을 구분한다. 정본의 옛 기준선에 최신 누적 변화를 적용하며 동적 값이 유실됐다고 초기값으로 채우지 않는다.
Supabase 정본 원문이 없거나 SHA/판본이 다르면 canon_source_required로 의존하는 결과만 보류한다. 장애 시 프로젝트 파일의 동일 SHA 원문을 확보해 한시적으로 활용할 수 있으나 Supabase 정본 조회 성공으로 가장하지 않는다. 필요한 사실을 일반 예시로 생성하지 않는다. 비공개 내용을 조회보고/HUD에 붙이지 않는다. 정본 읽기는 게임 시간/턴/난수/저장 행동이 아니다.

## PRIVATE_CANON_PERIODIC_REVIEW

정본의 Supabase 등록·활성 판본 교체·새 채팅 로드 시 전체 원문과 파일 해시를 한 번 확인한다. 기존 정기 재독은 Scene Turn20/40/60…에 도달한 뒤 열린 절차가 끝난 첫 안전 경계에서 수행한다. 동일 응답에서 같은 전체 원문을 이미 읽었으면 재사용한다. 여러 경계를 넘으면 현재 한 번, 다음 기준은 현재보다 큰 다음20배수다.
색인에 있는 활성 모든 절/파일의 실제 본문을 확보해 기준선+현재 누적 변화를 대조한다. 검색 발췌/잘린 원문/요약만으로 전체 완료라 하지 않는다. 기존 미저장 결과를 먼저 보존하고 사망·발견·취소를 초기화하지 않는다. 미래20턴의 사건/PC선택을 만들지 않는다.
판본·확인 범위·완료/누락·다음 기준을 현재 상태에 남긴다. 조회 실패는 미완료이며 필요한 현재 사실이 남아 있으면 플레이는 계속한다. 상태 변경/명시적 재시도/다음 정기 경계에 누락 범위를 다시 읽고 같은 장애를 매 응답 경고하지 않는다.
정본 재독20턴과 저장40턴은 별개다. 겹치면 같은 본문을 재사용한다. 재독을 위해 DB 저장/전체load를 추가하지 않으며 재독 성공을 저장 성공으로 대체하지 않는다. 이 주기는 무손실 기억의 보장이 아니다.

## STATE_CANON_SAVE_BINDING

신규 기본 DOCUMENT_BOUND(DB1)은 Supabase 비공개 정본 전문의 정확한 참조+완전한 누적 동적 상태를 결합한다. 정본 원문과 checkpoint는 같은 Supabase의 별도 저장 단위다. 현행 V2 서버 계약은 state_schema_version=TRPG_STATE_V2·save_mode=DOCUMENT_BOUND·document_bound_format=DB1이며, rules_version은 실제 사용한 룰북판을 별도로 기록한다. 버전 문자열로 삭제된 구형 상태필드나 이전 RNG 큐를 필수화하지 않는다. 새 RPC의 실제 수용/검증 계약을 확인한다. 룰북 업로드로 서버 계약이 바뀌지는 않는다.
| 구성 | 필요한 데이터 |
|---|---|
| canon_ref | campaign/canon ID·revision·filename·document_format·전체 바이트 file_sha256·필수 section_ids와 실제 PC/챕터 참조 |
| change_coverage | complete_since_revision=true; baseline_entity_ids와 changed_entity_ids의 npcs/evidence/locations/routes/drivers/threats6개 전체 집합 |
| world_delta | 같은6개 namespace별 정본 이후 누적 현재값/변경 근거. changed집합은 실제 object 키와 일치 |
| new_entities/tombstones/processed_event_ids | 신규 인물/단서/원문·사망/소모/취소/종결·실제 처리event, 현재 실행 플래그 |
| PC/진행 | session/campaign/규칙판·phase/챕터/턴·설정/시드·전원 identity/수치/자원/위치/장비·공개 사실/지도·시간·선언/판정/전투/질문 대기·약속/획득·저장주기·종료/후일담 상태 |
| 재개 문맥 | STATE_EXPERIENCE_CONTINUITY의 이야기·인물·현재 장면/미해결 상태와 원문/이벤트 참조 |
현행 V2 checkpoint payload 최상위에는 `session_id`, `campaign_id`, `rules_version`, `state_schema_version`, `save_mode`, `document_bound_format`, `checkpoint`, `canon_ref`, `change_coverage`, `world_delta`, `new_entities`, `tombstones`, `processed_event_ids`, `pcs`, `runtime`, `story_context`, `npc_contexts`, `scene_context`, `ongoing_consequences`, `critical_state_registry`, `manifest`를 둔다. 별도 JSON객체를 원문 상태에서 만들어 현재 맥락을 빠뜨리지 않는다. `checkpoint`에는 `version`·`event_id`·`attempt_id`·`parent_version`·`parent_sha256`를 두며 첫판의 parent는 명시적 null이다. `pcs`는 P1~P3 중 실제 인원만의 객체, `runtime`에는 phase·scene_turn·current_pc·pending을 포함한다. `canon_ref`에는 campaign_id·canon_id·revision·filename·document_format·file_sha256·필수10절의 section_ids를 둔다. 신규 세션에는 구형 RNG 큐가 필요 없다. 신규 canon_ref.file_sha256은 Supabase gm_canon_documents.file_sha256 및 전달한 Markdown 원본의 UTF-8 바이트 해시와 일치해야 한다. 첫 setup_bootstrap checkpoint 전에 해당 canon 원문과 read-back을 검증한다.
캠페인/챕터/최초프로필 전문·scenario_core/world_dna/canonical_map_model/world_state 같은 불변 전문은 매 전송에 중복하지 않고 정확한 정본 참조로 복원한다. 실제 신규/변경 정보는 제외하지 않는다. 마지막 저장 뒤 delta만 남기는 체인은 금지한다.
새 payload 객체를 만들되 작업 상태 자체는 삭제/축소하지 않는다. 실제 지원되는 기존 동적 namespace/runtime_flags 등에 재개 문맥을 보존할 수 있는지 계약과 read-back으로 확인한다. 필드를 거부/삭제하면 호환 실패다. 가짜 빈값이나 불변 전문을 다른 필드에 숨겨 통과시키지 않는다.
복원은 정본+누적 world_delta+new_entities+tombstones+processed_event_ids+PC/실행/재개 문맥을 결합한다. 파일 SHA/판본/coverage 누락은 canon_source_required 또는 checkpoint_canon_recovery_required로 해당 복원을 보류한다. DB1 차단을 감추려고 대용량 LEGACY_FULL을 자동 재전송하지 않는다.
기존 LEGACY_FULL 원문/해시/history는 유지한다. 명시적 해당 세션 변환 요청과 원문/정본 항목별 대조·필요한 새 판본·새 버전 verify/read-back 없이 자동 이관하지 않는다. 과거 GitHub 저장본은 삭제하지 않지만 신규 생성/자동 미러/복원 대상이 아니다. 기존 세이브의 참조는 소급 변경하지 않으며, 소유자는 기존 정본/구판 .md를 보존한다.

**본부 ON의 기존 종결 저장 계약:** 서버 변경 없이 기존 JSON에 다음 실제 값을 기록한다. OFF에는 요구하지 않는다.
- `runtime.hq.enabled=true`, `runtime.hq.mission_id`는 실제 임무 UUID, `runtime.hq.segment_key`는 해당 현지 구간과 정확히 일치시킨다. 추정 ID를 발급하지 않는다.
- `runtime.ending_state.scope`는 CAMPAIGN_TERMINAL/CHAPTER_TERMINAL/CHRONICLE_TERMINAL 중 실제 범위, `status`는 completed/failed, `finalization_event_id`는 실제 종결 event다. `returning_agent_ids`는 **실제 귀환하는 영구 요원 UUID 배열**이며 중복·미참가 ID·죽거나 SAN 0으로 행동 자격을 잃은 인물을 넣지 않는다. 전멸이면 빈 배열/failed이며 귀환/보상을 꾸미지 않는다.
- `pcs`는 실제 참가 P1~PN 객체이며 각 현재 담당 인물의 `player_id`는 연결된 영구 UUID, `alive`는 실제 생존/게임 진행 자격의 boolean이다. SAN 0도 게임 오버이므로 이 판정에서는 false로 기록하되 육체 사망과 광기 이유는 실제 HP/SAN·문맥에서 구별한다. 적법한 NPC 인계를 마친 경우 현재 인물의 새 identity/실제 상태를 잇고 이전 인물의 종료 기록은 보존한다. 연대기 종결 서버는 참가자당 정확히 하나의 player_id/alive·귀환자 alive=true·사망자 존재 시 failed·전체 completed의 전원 귀환을 요구한다.
- 최상위 `rules_version`과 등록 정본 규칙판·canon_ref·SHA를 일치시켜 STATE_COMMIT의 commit→verify→동일버전 read-back을 마친다. HQ의 `confirm_segment_terminal(segment_id, checkpoint_version, checkpoint_sha256, expected_revision)`에는 실제 **최신 verified** version/SHA와 최신 본부 revision을 사용한다. 필수 연결이 누락되면 기존 저장을 위조/덮지 않고 실제 계약 오류를 보고한다.

**신규 동적 저장의 의미 소유권(기존 DB1 수납):** 실제 서버의 `story_context`·`scene_context`·`ongoing_consequences`·`pcs`·`runtime`은 JSON 객체이고, `world_delta`는 기존6개 namespace다. **새 최상위 필드·테이블/RPC·정본 절·별도 진행률 장부 없이** 다음 사실을 그 담당 영역에 누적한다. 이는 E마다 의무 빈칸을 채우는 표가 아니라 실제 변화/활성 상태가 생긴 경우의 수납 계약이다.
- **일반 E/거대 G 세계 상태:** `world_delta.drivers[기존 E-ref]`는 정본 이후 실제 발생/활성·부분 대처/완전 해결·실패/미개입·차단과 남은 핵심 문제/변화 원인·근거 이벤트의 누적 현재 상태를 담당한다. `world_delta.npcs/locations/routes/threats/evidence`에는 그 결과 실제 바뀐 개체의 생사/인지·시설·출입/이동·유한 적·물품/소유만 기록한다. 거대 G 자체는 정본의 기존 참조를 유지하고 각 E가 실제 변경한 최종 대응 자원/위험만 누적한다. 단순 '현장 도착', 작은 목표·S 수락/완료나 화면 밖 전언을 E 완료로 기록하지 않는다.
- **PC별 현재 목적·정보와 E 세계 상태의 기존 저장 참조:** `story_context.main_track_by_pc`는 새 필수 스키마가 아닌 기존 체크포인트 재개 문맥이다. `world_delta.drivers`의 E/G 원인·진행·차단·세계 결산과 별개로 해당 P슬롯의 실제 선언/수락 목적, 직접 관측한 정보·위치/접근, 제안/보류/거절/완료·S/생활을 구별해 보존한다. E가 아직 남았다는 이유로 PC가 수락한 것으로 기록하지 않고 서로 다른 PC의 인지·장비/동행을 자동 복제하지 않는다. 기존 검증 세이브 비소급.
- **실제 행동권·열린 단계:** `pcs[Pn]`에 인물별 HP/SAN/Luck·중상/의식·의료품 사용/회복 제약·현금·실물명/수량/장착·구획/확장 가방·위치/확인된 지식을, `runtime`과 `scene_context`에 현재 행동권자·선택 메뉴 원래 intent/ref·열린 판정/전투/추격/광기·질문/대답 대기·미선언 이송/합류와 실제 시간 정산 경계를 보존한다. PC 교대와 저장/재개는 열린 행동의 자동 실행·재굴림·시간 증가가 아니다.
- **세계의 진행 중인 위험/구조:** `ongoing_consequences`에는 실제 화재/침수·감염/적 행동·운반/구조 등 **이미 성립한** 과정의 시작 사실/상대 경과·악화/완화/중단·관측자·관련 E/개체 ref를 보존하고, 실제 바뀐 대상은 각 `world_delta`에 반영한다. HP0 의식불명 PC는 해당 시점의 **실제 접근·이송 가능한 다른 생존 PC와 위치/퇴로·구조 진행·현장 위험**을 근거와 함께 남긴다. 구조자 전원 사망·실제 구조 불가능/일격 즉사로 이미 확정한 사망을 로드 후 의식불명으로 되돌리지 않는다. 구조자 전투 중이라는 이유만으로 불가능으로 만들거나 빈사 시계/전투 중 HP 회복을 추가하지 않는다.
- **원장과 공개 UI의 분리:** `processed_event_ids`는 실제 이미 적용한 event만 중복 없이 보존한다. `change_coverage.changed_entity_ids`의 여섯 집합과 `world_delta` 여섯 객체의 키는 **각 namespace별 정확히 일치**시킨다. 세계 개체가 변경되지 않은 PC의 목표/대화/HUD 변화만으로 가짜 드라이버 delta를 만들지 않는다. HUD는 06-play BOTTOM_HUD_CONTRACT의 고정 레이아웃으로 **현재 원장값을 투영**하며 초록/빨강 증감·경고 색상·화면 문자열 자체를 새로운 HP/물품이나 세계 사건으로 저장하지 않는다. 재개 직후 지난 턴의 색상 증감을 새 사건처럼 반복하지 않도록 `scene_context`의 마지막 실제 결과/표시 경계를 활용하되, UI 출력만을 위해 턴·이벤트·저장을 늘리지 않는다.
- **ON의 영속성 분리:** 이미 발급/승인된 본부 입단·카드 소유/영구 성장·작전평가/보상은 실제 기존 HQ/카드 원장을 우선한다. checkpoint에는 그 실행 단계/입력 대기·확인한 ref·현지 PC 스냅샷/실물 상태만 연결하고 재개로 지급·성장 적용·귀환/평가를 재실행하지 않는다. OFF에는 가상의 본부/카드 필드를 필수화하지 않는다.

## STATE_WORKING_CONTEXT

작업 상태는 실제 로드/생성한 데이터+이후 확정 변화다. 현재 문맥과 실제 지원되는 비공개 작업 공간만 사용한다. 추론을 영구 장부로 간주하거나 없는 파일/백그라운드 서버를 주장하지 않는다. 전체 보존 범위는 STATE_SCHEMA, 이야기/인물 맥락은 STATE_EXPERIENCE_CONTINUITY가 담당한다.

현재 처리에는 session/규칙판·설정/플레이 단계·관련 PC/장소·마지막 대화/열린 행동/판정·실제 다음 조건·미저장 변화만 유지한다. 실제 변화 때 피해/치료·물품/인계·새 합의/확인된 이해·말투/태도/관계의 이유·세계 원인/개체 상태와 의미를 즉시 갱신한다. 저장 때까지 미루거나 완료 장면의 과거 경험을 현재 요약으로 덮지 않는다.

E의 세계 발동/진행/해결·잔존 위험은 `world_delta.drivers`, PC별 실제 목적·지식/관측·제안/수락/거절·각 E 현장 직접 체험은 기존 `story_context/scene_context`의 지원되는 문맥에 구별해 잇는다. 원격 기여는 체험으로 인정하지 않는다. S/생활은 E 하위 작업과 구별하고 미발견/접촉/보류/거절/완료·NPC 독립 처리/소진과 후속 접촉의 출처를 보존한다. 현재 🎯에는 해당 PC가 실제 아는 상황·선택한 목적만 투영한다. 다른 PC의 위치·미전달 정보·수락을 자동 공유하지 않는다.

PC 교대/주요 결과에는 05-world SCENE_CONSEQUENCE_RULE의 관련 후속 접점만 확인한다. 새 GO·핵심 비밀/적·서버 컬럼/임의 event ID·매 턴 전수조회/저장을 추가하지 않는다. 신규 도입의 실제 생활/위치·play_start와 첫 E 접촉·실제 경과/Scene Turn을 보존하고 재개 후 1턴으로 초기화하거나 사건을 재예약하지 않는다.

반응형 후속은 실제 확정 후 기존 지원 상태·누적 변화에 기록한다. 열린 선택의 대상 PC·관련 NPC의 실제 위치/지식·미완료 결과를 잇고 재개에서 새 무작위 사건처럼 반복하지 않는다. 실제 read-back 전 영속 성공을 주장하지 않는다. 필요한 원본/과거 경험이 없으면 관련 부분만 실제 기록으로 복구한다. 현재 미저장 진행이 남아 있으면 저장 실패를 이유로 과거 snapshot을 다시 로드하지 않는다. 구판의 확정 ref·시계·생사·소유·완료/안전/종결은 소급 재설계하지 않는다.

## STATE_ACCESS_ROUTER

일반 응답의 기본값은 DB 조회0회다. 규칙은 담당 룰북, 현재 수치/비밀/원문/예정 사건은 작업 상태와 관련 정본을 쓴다. 현재 필요한 상태 필드/ref 또는 저장 작업과 실제 접근 사유가 있을 때만 호출한다.
허용 경계: 새 채팅/명시 로드, 필요한 상태의 실제 유실/충돌, 정상 저장의parent/commit/verify/exact read-back, 같은attempt 실패 복구, 사용자 명시 대조/목록, 최초/변경 연결 계약 확인. PC교대·대화·판정 요청/입력·이동·HUD 자체는 사유가 아니다.
여러 필요한 필드는 실제 지원되는 한 호출로 묶고 동일 version 원문은 재사용한다. 부분조회 미지원이면 exact snapshot 한 번을 사용하고 entity마다 전체load하지 않는다. 저장 검증은 생략하지 않으며 별도 명시적 삭제 지시 없이 delete하지 않는다. 저장 없는 테스트는 원본 쓰기/불필요한 재조회 없이 작업 분기에서만 진행한다.

## STATE_SCHEMA

보존 범위는 정본+동적 체크포인트를 결합한 전체 논리 상태다. 실제 경로/필드 허용은 확인된 서버 계약을 따른다.
| 범위 | 보존할 정보 |
|---|---|
| 식별/세계 | session/campaign/version/event/parent·규칙판·정본판본·phase/챕터/종료, 설정의 실제 입력/미입력·`permanent_cards_enabled`/종속 `permanent_growth_enabled`·start_seed와 생성 출처·확정 세계/지도 참조 |
| PC | identity/참가슬롯·공개프로필·특성/기능·HP/SAN/Luck/MOV/DB/Build·위치/현금/소지품(실제 점유·오른손/왼손·착용·빠른 접근·사용 준비)·부상/광기/진행성 위해·일일SAN기준/누적·회복 사용 |
| 인물/세계 변화 | NPC 생사/목적/지식/위치/Voice·상대별관습/합의/역할/다음행동·장소/경로/시설/소유/접근·낙하/인계 물품의 위치·공개된 원문·신규/취소/처리event |
| 이야기/경험 | 주요 원인/발견/목표 변화·관계/공동경험·태도 이유·준비/약속/획득·진행/차단/잔존 위험과 조건·STATE_EXPERIENCE_CONTINUITY의 연결 맥락 |
| E/G·PC별 목적/관측 | `world_delta.drivers`의 실제 E/G 세계 원인·발동/차단·부분/전면 해결·미개입·세계 여파와 `story_context.main_track_by_pc`의 PC별 선언 목적·현재 인지/접근/현장 직접 체험(원격 기여는 체험 불인정)·S/생활의 제안/수락/보류·결과/출처 분리. 기존 필드·구판 ref 호환 |
| 구조·현장 위기 | `pcs`의 HP0/중상/실물 의료 상태, 실제 구조 가능한 다른 PC·도달 경로와 `ongoing_consequences`의 악화/중단/이송 진행·물리 소요, 확정 사망/방어/치료 결과 |
| 고정 HUD 투영 | PC별 현금·인벤토리 구획/실물/수량·장착·상태, 현재 공개 목표와 조건부 이번 변화의 일회성 경계; HUD 색상/레이아웃은 저장 원장이 아닌 06-play의 표시 규칙 |
| 지식/대기 | 공개사실의 발견자/출처·NPC실제지식·가설/검증/미해결질문·마지막 대화/제안/수락대기·준비/소지/인계·중단 작업·분기선언 |
| 실행/난수 | 행동/판정ID·양측기능/요구값·PC원값/유불리후최종값/단계/비교·행운/강행동의/방법/고지위험/비용·Python출처/원값/적용단계·전투/추격/광기·턴/시간정산·현재메뉴/입력담당 |
| 유지/마무리 | 연대기학습/성장경계·후보/선택대기/적용전후·종료event/후일담완료항목·**본부 ON의 클라라 후일담 요청대기/열람진행과 실제 본부 장면**·지도공개/주석·실제이미지참조/외형기준·저장/재독주기/실패attempt·registry/manifest |
폐기 기능의 신규 상태를 만들지 않는다. 화면에 안 보이는 사실도 보존하며 실제 값과 근거를 점수/중복 장부로 바꾸지 않는다. 모든 UI·이미지는 상태의 투영이다. 새 기능/필드를 서버가 실제 거부하면 성공이라 하지 않고 호환 범위를 보고한다.

## STATE_IDENTITY

**신규 저장의 정확한 규칙판:** 배포 `RULESET.json`의 `rules_version`을 기존 checkpoint 최상위 `rules_version`과 정본 등록의 규칙판에 동일하게 기록한다. `TRPG-RULE-2026-11-17+sha256:<64자리>`는 실행 소스 12개의 경로/바이트 SHA-256 목록을 다시 SHA-256한 배포 식별자다. 날짜만 같아도 원문이 다르면 다른 판본이다. `SHA256.json`으로 실제 파일을 대조한다. 파일/해시를 확인할 수 없으면 식별자를 추측하지 말고 해당 버전 연결을 미확인으로 남긴다. 서버 `state_schema_version=TRPG_STATE_V2`와 규칙 배포판은 서로 다르며 새 컬럼을 추가하지 않는다. 기존 저장의 `rules_version`·정본 원문/해시는 변경·재해시하지 않고 당시 판본으로 재개한다.

P1/P2/P3는 참가 슬롯, PC identity는 인물 식별이다. 참가 인원/실제 슬롯/대상PC가 일치해야 한다. 같은 슬롯의 새 인물은 새identity이며 과거 인물의 개인 배경·시트·성장·이미지를 상속하지 않는다. 플레이어 공개 사실과 실제 전달된 PC별 극중 지식은 CORE_VISIBILITY에 따라 따로 보존한다.
**`permanent_cards_enabled=false`이면 카드 UUID/가입·클래스/장착·영구 성장 PC 링크/보상·효과를 생성/복원하지 않는다.** 값이 확인되지 않으면 기존 정본/체크포인트에서 먼저 확인하며 임의 ON으로 되돌리지 않는다. **ON에서만** 영구 카드 플레이어 ID는 PC identity/P슬롯과 별개의 UUID다. 자산·강화 카드의 실제 능력·소실/소모 및 영구 성장 적용/보상·장착은 09-cards.md의 CARD_SYSTEM_SCOPE·CARD_EQUIP_AND_ASSET·CARD_PLAYER_STORAGE를 따른다. **닉네임만으로 연결하는 신뢰형 운영**을 사용자 지시에 따라 적용한다. 중복 없는 닉네임을 입력하면 `public.card_login` 익명 RPC 또는 권한 있는 키퍼 연결로 영구 UUID·기본18·소유·성장을 확인한다. 로그인·비밀번호·추가 인증을 요구하지 않으며, **같은 닉네임은 같은 UUID이고 닉네임 사칭 가능성은 의도적으로 수용한다**. PC 연결 시 `trpg_cards.link_character`(또는 `public.card_link_pc`)가 그 시점의 성장 단계를 `applied_stats` 스냅샷으로 확정하고 같은 PC 재로드에서는 재적용하지 않는다. UUID/카드 소유·성장은 별도 영속 카드 DB에, PC 실물·동행·HP/SAN·실제 세계 상태는 종전 verified checkpoint에 둔다. 공개 `card_*`는 **원래 GM 세이브 RPC의 접근권을 바꾸지 않는다**. 두 저장 영역의 성공·실패를 혼동하지 않는다.
NPC/entity·원문·약속·물건·이벤트는 이름이 아닌 stable ref로 연결한다. 메뉴/대화/판정·중단 작업에는 현재 담당과 실제 선언 범위를 남겨 로드 후 자동 수락/실행하지 않는다. 이전에 형성/전달된 사건 연루와 완료한 확인도 보존한다.

## STATE_EXPERIENCE_CONTINUITY

저장 단위는 다음 대사·행동·판정·가능한 선택과 경험을 바꾸는 확정 사실 및 그 연결이다. 현재값이 맞고 사건 제목만 남은 저장은 충분하지 않다. 모든 대화 전문 대신 다음 범위를 실제 상태/근거ref와 연결한다.
| 구성 | 필요한 맥락 |
|---|---|
| story_context | 여기까지 온 주요 인과·발견·PC가 채택/변경/포기한 목표·선택과 여파·현재 국면/미해결 중심 문제 |
| npc_contexts | 기본말투/상대별호칭·존대/어휘/행동관습·공동경험·현재태도와 이유·협력/거절/지식/역할·필요하면 실제 짧은 발언 |
| scene_context | 현재 행동권/장소·직전행동과 반응·대화주제/마지막질문·확인된 의미·누구의 어떤 답/판정을 기다리는지·거리/장애물/자세/준비/인계 |
| ongoing_consequences | 약속·준비의효력·위해/치료·화면밖진행·잔존조건·다음접점·이미실행/차단/취소한event |
이 재개 문맥은 실제 사실을 설명하는 자연어/구조화 데이터이며 경쟁 정본이나 미래 대본이 아니다. 수치·물건·합의·이벤트는 각 실제 상태ref와 일치해야 한다. 필요한 맥락은 현재 장면 밖에도 남기며 인물이 잠시 안 나온다고 버리지 않는다.
당면 목적·겪고 있는 상황/압력·함께 행동하는 사람·쓸 수 있는 준비/수단·다음 대응은 기존 story_context/scene_context/ongoing_consequences에 보존한다. 단서 목록만으로 현재 경험을 대신하지 않으며 이를 위해 새 서버 필드/저장 수단을 가정하지 않는다.
의사소통은 방향과 범위를 가진다. A가 B의 말을 이해함은 A가 그 언어로 발화함/B도A를이해함/모든의도를앎과 다르다. 실제 통했던 방식과 확인된 의미·아직 모르는 요구를 남기고 로드 뒤 미확인으로 낮추지 않는다.
제안/수락·소유/소지·공개/양도·준비/실행·노출/피해적용·관측/전언/추론·confirmed/inferred/unknown을 구별한다. 필드 부재·unknown·false·true도 서로 다르다. 기록되지 않은 과거 감정/친밀감/대사를 추측하지 않는다.
변화가 생긴 때 해당 사실과 맥락만 갱신한다. 저장 직전 payload에서만 기준을 뽑아 자기검증하지 않고, 현재 작업 원문에서 중요한 값·관계방향·범위·출처·대기를 고정한 검증 기준을 만든다. 실제 read-back 원문과 정확한 canon_ref만으로 재구성한 논리 상태를 그 기준과 대조한다. 해시 일치는 바이트 보존이며 맥락/의미 충분성의 증명이 아니다.
첫 지문 전에 복원된 이야기·인물·현재장면을 적용한다. 이전 채팅 없이 이어쓰기 비교로 완료한 확인을 되묻는지, NPC말투/태도·목표/다음선택·준비/피해가 이어지는지 별도 평가한다. 값 비교 스크립트가 이 표현/적용 품질을 자동 검증하지는 않는다.
필수 사실 누락/확실성 하락/맥락 모순은 복원 연속성 미검증/누락으로 보고한다. 서버 verified만으로 완전한 최신 복원이라 하지 않는다. 실제 기록·현재 상태·사용자의 명시 확인으로만 보완하고 부분 복구라는 이유로 이미 아는 사실을 초기화하지 않는다.

## STATE_INTEGRITY

저장 경계에서 현재 full 논리 상태와 같은판본 정본/최신 의미유효 verified parent를 대조한다. session/identity/규칙판/정본SHA·참가슬롯·currentPC·턴/시간·세계변화·난수/미해결단계·장비/소유·진행성상태·학습/성장·마지막질문과 재개맥락이 일치해야 한다.
critical_state_registry와 manifest는 실제 활성 namespace/ref/내용을 가리켜야 하며 빈 이름 목록이 아니다. 불변 원문은 같은 정본/검증된ancestor에서만 복구하고 변하는 값을 과거snapshot으로 메우지 않는다. 현재/정본 사이 모순을 새 진실/동기로 합리화하지 않는다.
DB1의 6개 baseline/changed 집합·누적 delta·신규/취소/처리 event coverage 및 재개 문맥/실제 상태 참조를 확인한다. 저장 전 실제 의미를 대조할 때 **E의 세계 발동/차단/잔존 위험과 각 PC가 선언한 목적·현장 또는 실시간 원격 개입·직접 알게 된 사실**을 구분한다. 세계 해결과 별개로 참가 PC 전원의 현장 체험을 확인하며 한 PC의 해결은 다른 PC의 자동 지식/수락이 아니다. 검증된 기존 캐논 판본·world_delta/processed_event_ids·실물/부상/안전·저장 소유권을 보존하고 실제 read-back 없는 저장 성공을 주장하지 않는다.

## STATE_CADENCE

| 경계 | 저장 시도 |
|---|---|
| setup_bootstrap | 전원PC·세계·정본/연결 완성 뒤 시작 입력 대기 전1회 |
| play_start | 실제 게임 시작/scene_turn1·시작지도 전달 또는 대체 뒤 첫장면 전1회 |
| periodic_scene_turn | Scene Turn40/80/120… 도달/초과 뒤 열린 절차가 끝난 첫 안전 경계 |
| terminal_pre_finalization | 전체캠페인/연대기 종결event 및 ON 현지 각 챕터 종료 뒤1회. OFF 챕터만 종료하면 추가하지 않음 |
| manual | 저장/채팅이동 전 저장 등 명시 요청. 자동 주기를 초기화하지 않음 |
상태에는 최초/종료status·next_scene_turn·last_verified_version·deferred_reason/실패attempt를 보존한다. 여러 기준을 넘으면 현재 한 번 저장하고 다음은 현재보다 큰 다음40배수다. 실패한 자동 시도도 다음40배수로 옮기되 마지막 verified는 성공 전 갱신하지 않는다. 기존 체크포인트의 next_scene_turn이 옛30배수라면 이번 주기부터 현재 Scene Turn과 마지막 정기 저장 경계에 맞춰 다음40배수로 재산정한다. 이미 검증된 과거 저장을 변경하거나 과거 구간을 여러 번 소급 저장하지 않는다.
전투/추격/굴림/행운/광기의 열린 단계를 자동 저장으로 끊지 않는다. 수동 저장은 열린 단계까지 정확히 보존한다. 피해·이동·이미지·장면전환 자체는 추가 자동 저장 조건이 아니다. 저장은 시간/턴/난수/세계 진행이 아니며 성공 여부와 관계없이 STATE_SAVE_FAILURE_CONTINUE를 따른다.

## STATE_CHECKPOINT_RECAP

게임 시작과40배수 저장에서는 동일 version verified exact read-back을 재사용해 정본+전체 동적 상태를 대조한다. 수동/종료/로드도 이미 확보한 원문과 검증 결과를 재사용한다. 복기만을 위한 latest/list/추가 full load를 만들지 않는다.
현재 장면 밖을 포함한 NPC/단서/장소/경로·활성/취소/휴면위협·미해결약속·PC/난수/입력대기·이야기/인물/장면문맥과 출처가 있는지 확인한다. 잘린 원문은 실제 누락 범위를 확보하고 전체완료라고 하지 않는다. 변경없는 불변 전문을 매40턴 새로 생성하지 않는다.
검증 원문을 바탕으로 현재 작업의 관련 맥락/다음조건을 정리하되 요약으로 원본을 대체 저장하거나 미래40턴을 생성하지 않는다. 읽기/대조는 시간·사건·피해·성장을 다시 적용하지 않는다. 실패 시 현재 확인 가능한 상태로 복기하고 verified 복기라 부르지 않는다. 비밀 복기 보고를 공개하지 않으며 무손실 기억 보장을 주장하지 않는다.

## STATE_COMMIT

캠페인당 Single Writer. 같은 저장 요청은 같은 attempt로 처리한다. 신규 setup_bootstrap 전 원본 .md와 같은 내용을 Supabase 비공개 trpg_private.gm_canon_documents의 (campaign_id,canon_id,revision)에 등록해 전체 내용·SHA-256을 read-back한다. 기존 revision 충돌 시 덮어쓰지 않고 동일성만 확인한다. 별도 필드를 V2 checkpoint에 추가하지 않으며 이후 매 체크포인트에서 canon 전문을 다시 전송하지 않는다.
1. STATE_INTEGRITY와 저장 전 경험/맥락 기준을 고정하고 실제 모드의 별도 payload를 만든다. 최신 verified+1 version·event_id=<session_id>:cp<version>·parent를 확인한다. 작업 상태를 축소하지 않는다.
2. 쓰기 전에 UTF-8 state_json 원문·session/version/event·SHA-256을 동결한다. 같은 attempt 도중 다른 상태로 재직렬화/재번호하지 않는다.
3. 정확한 계약으로 pending commit하고 raw 원문/hash/식별자를 확인한다.
4. 동일 원문과 의미/parent/manifest를 verify한다.
5. 같은 version의 verified 원문을 exact read-back하여 문자열·SHA-256·session/version/event/parent와 정본 결합 의미/재개맥락을 대조한다. 모두 확인돼야 저장 완료다. HTTP성공/파일명/해시문자열만으로 완료라 하지 않는다.
6. 같은 원문으로 STATE_CHECKPOINT_RECAP을 수행하고 이후 최신 미저장 변화는 보존한다. exact load 요건을 충족한 read-back을 중복 조회하지 않는다.
idempotent_replay는 같은attempt 존재를 뜻하므로 실제 verify/read-back 상태를 이어 확인한다. cadence 성공은 검증 뒤 반영하고 payload 내부pending을 사후 수정/재해시하지 않는다. API 객체/문자열/hash 직렬화는 서버 계약대로 하며 가정하지 않는다. 경험 비교 미실행/실패는 서버 verified와 별개로 복원 연속성 미검증을 표시한다.
현행 V2의 연결 계약은 `public.trpg_v2_commit(session_id text, version bigint, event_id text, attempt_id text, parent_version bigint, parent_sha256 text, state_json text, state_sha256 text)` → `public.trpg_v2_verify(session_id text, version bigint, event_id text, attempt_id text, state_sha256 text)` → `public.trpg_v2_load_version(session_id text, version bigint)` 순서다. 실제 SQL 호출 시 각 인자명 앞에 `p_`가 붙고, 순서는 위와 같다. 원문 UTF-8 바이트 SHA-256를 동결하고 서버가 같은 원문/parent를 검증한다. `trpg_v2_load`는 최신 verified만, `trpg_v2_list`는 각 세션 최신 verified 메타만, `trpg_v2_inspect_pending`은 해당 세션 미확인 시도만 반환한다. 정상 재개는 pending이 아닌 verified를 선택한다. 인증 없는 Data API·일반 authenticated·anon에 데이터/RPC 권한이 없으며 권한을 풀어서 통과시키지 않는다.

## STATE_VERIFIED_OWNER_AUDIT_AND_GITHUB_BACKUP

소유자의 명시적 비공개 감사는 플레이 밖 읽기 전용이다. Supabase의 정확한 canon revision과 session/version verified 체크포인트를 조회해 원문·SHA-256·정본 참조·누적 상태를 확인한다. 확인하지 못한 항목과 권한 제한을 사실대로 알린다.
이 절의 GITHUB_BACKUP은 구판 호환 ID다. **모든 정상 저장 경계(setup_bootstrap, play_start, 40턴, 수동, 종결)는 Supabase commit → verify → 동일 version exact read-back만 수행**한다. GitHub verified snapshot·MANIFEST·INDEX·REVIEW 등 추가 미러를 생성/갱신하지 않고 github_backup_pending도 새로 만들지 않는다. 정본 원문은 신규 캠페인/개정 때만 저장하며 매 체크포인트에 중복 쓰지 않는다.
과거 private GitHub 백업·비상본은 삭제하지 않고 역사 자료로만 보존한다. 공개 GitHub 저장소는 룰북/검증/배포 ZIP 전용이다.

## STATE_GITHUB_FAILOVER_PROTOCOL

구판 호환 절 이름이다. **GitHub 자동 백업·비상 체크포인트 저장·failover는 폐지**한다. Supabase 장애/차단/검증 실패 시 STATE_SAVE_FAILURE_CONTINUE와 STATE_RECOVERY로 현재 작업 상태·고정 attempt 원문·마지막 확인된 verified를 보존하고 공식 Supabase 계약으로만 재시도한다. 새 private GitHub JSON/meta/manifest를 만들지 않는다.
Supabase 읽기가 불가능하면 소유자가 제공한 동일 SHA 비공개 .md와 현재 작업 상태만 확인 가능한 범위에서 사용한다. DB 최신 버전이 불명확하면 완전 복원이라 말하지 않는다. 기존 GitHub 사본은 사용자가 과거 백업 대조를 명시적으로 요청한 때에만 읽기 전용으로 살펴보며, 자동 승격·재작성·삭제하지 않는다.
## STATE_SAVE_FAILURE_CONTINUE

세이브 실패는 게임 진행을 막지 않는다. setup_bootstrap/play_start/periodic/manual/terminal 모두 현재 상태가 있으면 시작·진행·종료를 계속한다. 재개 승인/실패 수락을 반복 요구하지 않는다. 실패·미확인을 저장완료/새채팅복원가능으로 표시하지 않는다.
최초 실패·상태변경·수동저장 결과·채팅이동 요청 때 마지막 실제 verified 지점과 미완료를 짧게 알린다. 매응답 같은 경고/자동재시도를 반복하지 않는다. 다음 정상 경계/수동요청/실제복구 때 재시도한다.
이미 제출한 pending 원문/hash/version/event는 동결하고 이후 진행은 별도 변경으로 보존한다. 연결 복구 시 기존attempt를 대조/정리한 뒤 그동안 진행한 최신 상태를 별도 체크포인트로 저장한다. 늦게 끝난 과거attempt를 현재까지 저장됐다고 하지 않는다.
충돌/여러작성자는 원격쓰기·자동병합을 보류하고 현재 작업 분기는 보존한다. 실제 유실된 수치/정본/판정은 관련 결과만 복구하며 저장장애와 구분한다. 원문/맥락이 실제 남아 있지 않으면 복원됐다고 하지 않는다. 종료 저장 실패도 결말/후일담을 막지 않는다.

## STATE_RECOVERY

pending 뒤 verify/read-back 중단은 일반 일시 오류에 한해 같은 version/event/원문으로 자동 재시도 최대1회. 명시적 안전 차단은 우회하지 않는다. 실패로 난수/사건을 다시 실행하지 않는다.
orphan pending은 최신verified+1(없으면1),event규칙·exact원문/hash·의미/parent/manifest 연속성을 모두 확인한 뒤 같은 원문으로 verify를 완결한다. 여러 충돌pending/버전gap/다른원문/손상은 자동 승격·폐기하지 않는다. checkpoint_write_recovery_required로 남기고 현재 플레이는 계속한다. pending은 verify 전 정상재개 정본이 아니다.

## STATE_RESUME

새채팅/명시로드/실제상태유실 때 적용한다. 현재 상태가 있는데 저장만 실패했다고 재로드하지 않는다.
**신규 의미 복원 순서:** (1) verified 원문·canon revision/SHA·누적 coverage, (2) `world_delta.drivers`의 주요 E와 연관된 개체의 **실제 세계 상태**, (3) `story_context.main_track_by_pc` 또는 구판에 실제 남아 있는 PC별 목표/지식 출처·선택한 S/작은 활동, (4) `pcs/runtime/scene_context/ongoing_consequences`의 구조 가능성·물리 경과·열린 행동/이동·장비/치료, (5) 현재 PC에게 공개 가능한 고정 HUD의 순서로 재구성한다. 세계 E의 완료와 PC별 직접 체험은 서로 다른 사실로 비교하고 현재 문맥의 명칭만으로 누락·S를 E로 승격하지 않는다. **구판 verified**에서 `current_carrot/main_goal_ref/active_main_goals` 등 서로 다른 이름이 확인되면 실제 정본 E-ref·PC의 관측/수락과 원문 근거가 일치하는 범위만 새 표준 문맥에 연결한다. 부재/불일치를 임의 추정해 채우거나 저장된 원문을 고쳐 쓰지 않는다. 실제 새 체크포인트의 검증된 누적 변화부터 적용한다. 화면 밖 위해의 시각·대기 판정·확정 피해를 로드 때문에 다시 진행시키지 않는다.

1. 실제 연결·소유권·session을 확인하고 표시이름/P슬롯만으로 선택하지 않는다. **종료 상태의 본부 OFF는** 기존 남은 엔딩/다섯후일담을 복구한다. **본부 ON은** 검증된 현지 종료 뒤 현재의 **실제 본부 귀환 단계(제이든 동기화실 대화 → 실제 마틴 면담·평가 → 플레이어가 요청한 경우만 클라라 후일담 열람)**와 미열람/열람된 편을 구별하여 복구한다. 종료 상태를 현지 위험/PC 행동권으로 재진입시키거나 클라라 요청 없이 후일담을 자동 출력하지 않는다.
2. orphan pending은 STATE_RECOVERY로 확인하고 최신 hash-valid verified의 exact 원문과 의미를 읽는다. DB1은 같은정본 전체SHA/판본/필수절/coverage를 확인하고 전체 누적world_delta·new_entities·tombstones·processed_event_ids와 PC/실행/재개문맥을 결합한다. LEGACY_FULL은 원문을 유지한다.
3. 첫 설정의 `permanent_cards_enabled`와 종속 성장 모드를 실제 정본/상태에서 복원하고 OFF이면 카드 로그인/장착·보상/성장을 실행하지 않는다. STATE_CHECKPOINT_RECAP/STATE_EXPERIENCE_CONTINUITY로 수치·이야기흐름·관련인물의말투/태도/이유·현재장면/마지막질문/확인된의미/입력대기를 함께 복원한다. 최초 장면 전에 적용한다. 정본 전체 확인은 PRIVATE_CANON_PERIODIC_REVIEW와 같은 원문을 재사용한다.
4. 저장된 열린 판정·전투·선언·메뉴·행동권·시간/위해단계에서 이어간다. 완료한 확인/합의를 미확인으로 되돌리지 않고 말못함을 이해못함으로 바꾸지 않는다. 새 채팅이란 이유로 생성·굴림·시간·피해를 재실행하지 않는다.
Supabase 실패 시 마지막 확인된 DB verified와 작업 상태를 구분한다. 소유자 .md 원문의 해시를 확인할 수 있지만 GitHub를 자동 조회하거나 신규 세이브를 생성하지 않는다. 최신미저장/다른분기와 섞지 않는다. 실제기록·사용자확인으로 필요한 누락만 보완하고 부분복구를 완전최신이라 하지 않는다. 로드 자체/현실경과는 게임조건을 진행시키는 행동이 아니다.

**본부 ON 엔딩·후일담 저장 경계:** ENDING_FINALIZATION_GATE에서 확정된 실제 결말·`finalization_event_id`·`ending_state`의 후일담 완료/대기와 그 출처는, 귀환/평가의 별도 HQ 기록과 **같은 사건 ref로 연결**한다. **다섯 편을 미열람했다고 terminal 검증/제이든 귀환/마틴 평가를 막지 않는다.** 클라라를 통한 후일담 요청·편별 열람은 원래 결말의 읽기/표시이지 세계 시간·HP/SAN·보상·finalization을 다시 굴리는 이벤트가 아니다. 실행 중인 실제 본부 단계/질문 대기는 허용된 현재 작업 맥락과 기존 HQ 원장에 둔다. 세이브 계약이 추가 필드를 지원하지 않는데 영속 재조회 완료라고 가정하거나 새 V2 top-level/DB 칼럼을 발명하지 않는다. 임무 결과·클라라 확인 가능한 사실/출처는 기존 검증된 checkpoint/정본 및 HQ archive로만 재구성한다. **진행 중인 세이브·이미 완료한 구판 결말의 후일담은 소급 재생/삭제/재작성하지 않는다.**

## STATE_COMPATIBILITY

이 절의 날짜별 항목은 **해당 시점에 생성·확정된 구판의 비소급 기록**이다. 신규 생성은 현재 담당 원문인 HP_AND_DEATH/HEALING/PC_DERIVED_STATS를 적용하고, 아래의 이전 중간 판본 수치·조건을 현행 규칙으로 다시 적용하지 않는다. 이미 확정된 기존 캠페인은 자신의 검증된 판본을 유지한다.

**2026-11-17 안정화 경계:** 신규 세계는 전원 각 E 현장 직접 체험 → 모든 E 뒤 최종 국면, 원격 기여 불인정·E 위기 선확정 보장·조기 성공 종결 없음이다. 비PC HP0 즉사·SAN0 게임 오버·전멸 무보상·카드 합산/최종 피해·보너스 상쇄/동시 사용 금지 등은 현재 담당 원문을 따른다. 새 저장부터 STATE_IDENTITY의 정확한 배포 식별자를 사용하며 과거 날짜 문자열/세이브·이미 확정된 결과를 바꾸지 않는다.

**2026-11-13 신규 PC HP 경계:** 당시 판본에서 생성·확정된 PC의 시작/현재/최대 HP는 `floor((최종 CON+최종 SIZ)/10)+1`로 **한 번** 확정된 과거 사실이다. 영구 성장 ON이면 PC 최초 링크에서 검증된 적용 특성값을 따른다. 이전에 확정된 PC·같은 PC의 재개/재링크·기존 verified 세이브/캠페인·NPC/적/동물 HP에는 소급 적용하거나 +1을 중복 지급하지 않는다. 현재 HP 변화는 실전의 실제 피해/치료만 반영하고, 중상·즉사·빈사/치료 절차와 적의 피해식은 기존 그대로다. 저장 스키마·RPC를 추가하거나 과거 원문을 수정하지 않는다.

**2026-11-15 신규 PC HP·의료 균형 경계:** 이 패치 이후 **새로 생성하는 PC**는 최초 확정 시작/현재/최대 HP만 `floor((최종 CON+최종 SIZ)/10)+2`로 계산한다(직전 판본 대비 +1). 같은 PC의 재연결/로드·성장으로 추가 지급하지 않고 이전의 +1 PC·NPC·적·동물에게 소급하지 않는다. 당시 캠페인 의료품 치료량은 HEALING의 파우치 1d2/현장 구급상자·수술도구 1d3과 동일 손상 1회성 처치였다. 그 판본의 CARD_ASSET_GU/CARD_ASSET_NE도 확정된 당시 산식을 따른다. **기존 verified 캠페인의 실제 확정 치료/카드 효과·부상·소모 기록은 종전 계약으로 유지**하며, 저장 내용을 재작성하거나 캐릭터를 재계산하지 않는다. 새 필수 DB 필드·RPC 없음.
**2026-11-15 신규 의료품 1회용·반복 치료 경계:** 당시 패치판에서 생성된 캠페인은 소형 1d2/구급상자·전문 일회용 키트 1d3+1을 적용했으며, **전문 키트 수치는 아래 후속 상향과 현행 HEALING이 우선**한다. 당시 나머지 의료품 계약은 한 의료품 전체 소모·성공/실패 공통 소멸, 잔여 최대 HP까지 복수 독립 치료를 따른다. INVENTORY의 **회복 의료품 계열별 PC당 1개**(소형/일반/전문) 소지 제한은 손·가방/파우치 등 모든 휴대 위치와 카드 자산 실물에 동일하게 적용한다. CARD_ASSET_NE/CARD_ASSET_GU는 캠페인 시작에 실제 각각 1개만 지급하고 치료 시 소진되며 재지급하지 않는다. 같은 부상별 성공 횟수/회분 전용 새 DB 필드는 추가하지 않는다. 기존 검증 세이브/원장·확정 아이템 수량/HP 효과는 소급 수정하지 않는다.
**2026-11-15 신규 빈사 제거·전문 키트 상향 경계:** 당시 중간 판본에서는 신규 PC/NPC의 HP 0을 중상 여부와 관계없이 Unconscious로 처리하고 Dying/빈사 단계·라운드별 CON 사망 굴림·안정화 이벤트를 생성하지 않았다. **이후 새로 생성되는 PC의 HP 0은 다음 신규 PC 구조형 HP 0 경계 및 현행 HP_AND_DEATH의 구조 가능성·즉사 조건을 우선 적용**하며, NPC/적은 별도 비PC 처리를 유지한다. 한 번의 실제 피해가 최대 HP 이상인 즉사 조건, 물리적으로 치명적인 위험·확정 사망·Major Wound/출혈·부상·의식 회복 조건은 보존한다. 신규 전문 일회용 처치 키트는 성공HP1d3+2(3~5)로 변경하며 소형1d2·일반구급1d3+1, 의료품 종류별 1개·사용 성공/실패 모두 1개 소모는 그대로다. 과거 verified 상태의 Dying·치료·카드·생사·정본은 자동 치유/변환/재작성하지 않는다. 신규 DB 스키마/상태 필드는 요구하지 않는다.
**2026-11-15 신규 PC 구조형 HP 0 경계:** 이 패치 뒤 생성되는 신규 캠페인 PC의 HP 0은 그 순간 같은 현장의 다른 살아 있는 **실제 구조 가능 PC**가 있을 때만 의식불명으로 남고, 없다면 즉시 사망한다. 이후 구조 PC 전원이 사망하거나 실제 접근/이송이 불가능해지면 즉시 사망한다. 구조자가 전투 중이라는 사실 자체는 불가능이 아니며, 실제 위협 수습·안전 장소 이송·적절한 치료 성공HP≥1에서만 의식을 회복한다. 전투/추격·진행 위해 중 HP 회복 금지; 중상 CON 실패만으로 의식불명 만드는 단계 삭제. 한 번 피해≥최대HP 즉사, 남는 중상/위해, 소형/일반/전문 1회용 의료품 산식·소지 한도, 구판 NPC/PC·확정 세이브 및 영구 카드/이미 확정한 사망 비소급은 유지한다. 다른 PC의 위치·도달 가능한 경로/실제 구조 가능성이 검증된 기존 위치/행동 맥락에 없으면 새 구조자나 가능 경로를 발명하지 않는다. 새 저장/DB 필드는 요구하지 않는다.
**2026-11-12 신규 규칙판 경계:** 신규 PC에는 SAN_CORE의 새 시작/현재/기본 최대 SAN 산식을 적용하고 수치형 크툴루 신화 기능·99−Mythos 상한·해당 성장 항목을 생성하지 않는다. 신규 체험 도달·원작 패턴·성취형 SAN 회복 설계는 신규 세계/미확정 챕터에만 적용한다. **2026-11-08 이하 기존 캠페인**은 당시 확정한 POW/SAN 및 크툴루 신화 필드와 광기/손실, NPC·적·사건·정본 SHA를 그대로 보존하고 해당 판본으로 정상 재개한다. 구판 기록을 신판 기능/수치로 자동 변환하거나 `0`·`null` 값으로 덮지 않는다. 실제 저장계약/필수 필드가 신판 생성 구조를 지원하지 않으면 임의 스키마 변경이나 가짜 필드 대신 해당 부문을 보류·호환 검토한다.

기존 verified 원문/history/hash를 수정·재해시·필드 삭제하지 않는다. 구판은 해당 규칙판으로 재개하거나 명시적 변환 경로를 적용한다. 기존 생사/시간/성장/확정난수·PC/지도·합의·발화/이해는 보존하고 없는과거/횟수/시드를 만들지 않는다.
신규는 핵심시드·생활버프·태그/공명·무료직업품·교대카운터/준비Gate·공개수첩 상태와 전문 분야/별도 전문성 성장 필드를 생성하지 않는다. 신규 직업 **기본 지급 물품**은 필수 1개만 갖는다. 별도로 장착한 영구 카드 자산의 **캠페인 시작 1회 실물 지급**은 이 직업 기본 지급과 구별하여 추가할 수 있으며, 소지/소모/손실은 현재 상태에 기록한다. 구판에서 확정된 물품·전문성은 기존 저장 원문/규칙판에 보존하고 소급 삭제하지 않는다. 기존 폐기 상태/수치는 구판 원문에 보존한다. 삭제필드를 서버가 필수로 요구하면 호환 문제이며 가짜0/빈값으로 통과시키지 않는다. 문서판과 실제 state_schema_version은 다르며 운영DB 변경은 자동 승인되지 않는다.
구판 rng_queue/rng_mapping_version/소비위치는 과거 기록으로 유지, 미사용큐는 중단하고 새 난수는 PYTHON_SYSTEM_RANDOM_V1로 기록한다. 이미 산출/공개/적용한 값과 실행단계는 그대로이며 불명확하면 복구 전 재굴림하지 않는다. Python 커널/파일/Random객체는 세이브가 아니다.
구판 이미 열린 성장/숫자메뉴/행운 동의는 그 의미와 범위로 한 번 마친 뒤 새 규칙으로 전환한다. 이미 열린 구판성장01의1d5/펌블1d3은 실제Python으로산출하되 기존획득치는보존하고같은사건을신규학습근거로재지급하지않는다. 대사건 신규성장을 과거에 소급 지급하지 않는다.
강화된세계/위험 설계는 신규/미확정챕터부터 적용한다. 기존 비밀·위협 능력·완료 성과를 소급 증설/취소하지 않는다. 장면/상태 연속성 누락은 실제기록·현재작업·사용자확인 근거로만 보완한다.
