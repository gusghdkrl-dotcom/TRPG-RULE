# 규칙 색인

규칙판: 플레이 개선판 2026-10-29. 실행 파일은 이 폴더의 Markdown 문서다. 과거 문서·개발 일지를 검색 정본으로 사용하지 않는다.

## 조회 순서

현재 선언과 상태에서 필요한 항목을 찾고 링크의 규칙 본문을 읽는다. 숫자·예외가 필요한데 본문을 읽지 못하면 추측하지 않는다. 현재 대화에서 확인 가능한 동일 규칙판 본문은 재사용하고 유실·변경된 부분만 다시 조회한다. 아래 링크는 검색 경로이며 상세 절차를 복제하지 않는다.

| 상황 | 읽을 규칙 |
|---|---|
| 이번 입력과 열린 절차부터 확인 | [CORE_WORKFLOW](01-core.md#core_workflow) |
| 일상 행동·판정 필요 여부 | [FICTION_FIRST_ROLL_TRIGGER_GATE](02-checks.md#fiction_first_roll_trigger_gate) |
| PC 주도권·대사·감정 | [CORE_AGENCY](01-core.md#core_agency) |
| 비공개 정보·PC별 지식 | [CORE_VISIBILITY](01-core.md#core_visibility) |
| 난수 큐와 일반 주사위 | [AI_DIE_MAPPING_VERSION](01-core.md#ai_die_mapping_version) |
| 성공 단계·펌블 | [SUCCESS_LEVELS](02-checks.md#success_levels) |
| 보너스·패널티 | [BONUS_PENALTY_DICE](02-checks.md#bonus_penalty_dice) |
| HP·중상·사망 | [HP_AND_DEATH](02-checks.md#hp_and_death) |
| SAN 노출 | [SAN_EXPOSURE_GATE](03-danger.md#san_exposure_gate) |
| 전투·총기·추격 | [COMBAT_ORDER](03-danger.md#combat_order) |
| 일반 턴 조회·도구·출력 최소화 | [TURN_RESPONSE_BUDGET](01-core.md#turn_response_budget) |
| 시작 입력·필수 값 누락·설정 대기 | [START_SETTINGS_GATE](04-setup.md#start_settings_gate) |
| 시작 인원 1~3명 확정 | [PARTICIPANT_COUNT_SETUP](04-setup.md#participant_count_setup) |
| 새 캠페인 전체 순서 | [CAMPAIGN_SETUP_PIPELINE](04-setup.md#campaign_setup_pipeline) |
| 원작 후보 A~F | [HOMAGE_DRAFT_SELECTION](04-setup.md#homage_draft_selection) |
| PC 특성+Luck 후보 | [STAT_DRAFT_GENERATION](04-setup.md#stat_draft_generation) |
| APP 반영 외형·확정 시점 | [PC_APPEARANCE_FROM_APP](04-setup.md#pc_appearance_from_app) |
| 직업 A 일상/B 특별·고위 대비 | [PROFESSION_SIX_CHOICE](04-setup.md#profession_six_choice) |
| 직업·기능 시작값 | [PC_SKILL_START_VALUES](04-setup.md#pc_skill_start_values) |
| 원작 특징을 실제 세계에 구현 | [HOMAGE_SIGNATURE_FREEZE](04-setup.md#homage_signature_freeze) |
| 실패·방치의 중대한 손실 설계 | [CAUSAL_ENDGAME_PRECOMMIT](04-setup.md#causal_endgame_precommit) |
| 도주와 남겨진 대가 | [NO_CLEAN_EXIT_HORROR_ARCHITECTURE](05-world.md#no_clean_exit_horror_architecture) |
| 세계의 PC 설정 활용 | [WORLD_PC_INPUT](04-setup.md#world_pc_input) |
| 생성 후 검증 | [COMPATIBILITY_GATE](04-setup.md#compatibility_gate) |
| 비공개 세계·NPC 시간 진행 | [WORLD_INITIATIVE_EXECUTION](05-world.md#world_initiative_execution) |
| 증거·가설·결론 | [EVIDENCE_NAMESPACE_CONSOLIDATION](05-world.md#evidence_namespace_consolidation) |
| 기능의 캠페인 내부 성장 | [SKILL_IMPROVEMENT](04-setup.md#skill_improvement) |
| 턴과 실제 시간 | [SCENE_ELAPSED_TIME_SETTLEMENT](06-play.md#scene_elapsed_time_settlement) |
| 2인 이상 행동권 | [SPOTLIGHT_FAIRNESS_COMMIT_GATE](06-play.md#spotlight_fairness_commit_gate) |
| 대표 행동·자유 선언 | [GUIDED_ACTION_RETURN](06-play.md#guided_action_return) |
| 일반 HUD | [BOTTOM_HUD_CONTRACT](06-play.md#bottom_hud_contract) |
| 업무를 목적 단위로 처리 | [CINEMATIC_ELLIPSIS](06-play.md#cinematic_ellipsis) |
| 초반 30턴·진행 정체·페이싱 | [SCENE_PACING_GATE](06-play.md#scene_pacing_gate) |
| 챕터·전체 엔딩 | [ENDING_FINALIZATION_GATE](06-play.md#ending_finalization_gate) |
| 지도 열람·이동 | [MAP_RUNTIME_INTERACTION](08-visual.md#map_runtime_interaction) |
| 직업·풍경·상황 웹 참고 | [WEB_VISUAL_REFERENCE](08-visual.md#web_visual_reference) |
| 이미지 선택 | [VISUAL_CHOICE_GATE](06-play.md#visual_choice_gate) |
| Supabase 연결과 정본 | [STATE_AUTHORITY](07-state.md#state_authority) |
| 저장 시점 | [STATE_CADENCE](07-state.md#state_cadence) |
| 저장 검증·중단 복구 | [STATE_COMMIT](07-state.md#state_commit) |
| 새 채팅 로드 | [STATE_RESUME](07-state.md#state_resume) |
| 수첩 동시 쓰기 방지 | [NOTEBOOK_WATCHER_RUNTIME_SINGLE_WRITER](09-notebook.md#notebook_watcher_runtime_single_writer) |

## 문서와 역할

- 01-core: 원칙·입력 해석·난수.
- 02-checks: 판정·Luck·HP·회복.
- 03-danger: SAN·광기·전투·추격.
- 04-setup: 원작·PC·직업·세계 생성.
- 05-world: 탐사·증거·NPC·세계 인과.
- 06-play: 시간·멀티 PC·HUD·페이싱·엔딩.
- 07-state: 비공개 상태·Supabase 저장·복원.
- 08-visual: 지도·초상·장면 이미지.
- 09-notebook: 공개 수첩.

## 공통 용어

PC는 플레이어가 조종하는 인물, P슬롯은 현재 참가 좌석이다. NPC는 키퍼가 진행하는 인물이다.

확정(Freeze)은 원작·세계의 핵심 진실·PC 과거 등을 더 이상 연출에 맞춰 다시 쓰지 않는 경계다. 확정된 진실과 별도로 현재 위치·피해·소유·NPC 행동 결과는 실제 인과에 따라 갱신한다.

Scene Turn은 시간이 드는 의미 있는 행동의 진행 번호다. 실제 경과시간·채팅 메시지 수·실제 플레이 회차와 다르다. 독립 장면은 하나의 행동 목적을 중심으로 이어지는 장면이며, 직접 결과가 끝나 다음 목적을 선택할 수 있을 때 전환 경계가 된다.

정보 공개 범위(FOG)는 해당 PC가 관찰·전달·검증한 범위다. GM_STATE는 공개·비공개를 포함한 게임의 작업 상태, Checkpoint는 그 전체 상태를 검증해 보존한 저장본이다. HUD·수첩·이미지는 공개 투영이다.

영어 코드 형태의 필드·enum은 실제 저장/도구 계약과 연결된 식별자다. 한국어 표현을 다듬는 이유로 필드명을 임의로 바꾸지 않는다.
