# 현재 룰북 배포 식별자

rules_version: `TRPG-RULE-2026-11-17+sha256:58fe4677622ecf056ccb3c1df73ac34e2aea5cb00b43f619cf73a0442b25430c`

같은 ZIP의 RULESET.json과 동일한 메타데이터입니다. 게임 정본/세이브가 아닙니다.
신규 정본과 기존 저장 계약의 rules_version에 이 실제 식별자를 사용합니다.
기존 게임도 현재 소스의 최신 룰북으로 진행합니다. 과거 rules_version은 이력이며 확정 상태/저장 원문은 보존합니다.
SHA256.json으로 실제 소스 일치를 확인하고 혼합 파일/미확인은 검증 완료로 표시하지 않습니다.
