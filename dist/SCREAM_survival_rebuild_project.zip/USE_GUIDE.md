# 별도 새 캠페인 사용법

이 묶음은 비공개 키퍼 설계이며 범인/미래 조건이 포함된다. 공개 GitHub·공통 룰북 ZIP·공개 채팅에 올리지 않는다. 플레이어가 줄거리 미리보기를 원하면 PLAYER_BRIEFING.md만 확인한다. 프로젝트 파일 접근자에게 내용을 기술적으로 숨기는 기능은 아니다.

1. 공통 최신 ZIP의 PROJECT_INSTRUCTIONS.md를 프로젝트 지침에 복사하고 sources/00-index~08-visual의9개 파일을 게임 소스로 교체한다. 공통 ZIP 주소: https://github.com/gusghdkrl-dotcom/TRPG-RULE/raw/refs/heads/main/dist/TRPG-RULE-project.zip . 이 설계의 기준 커밋은 MANIFEST.json에 기록했다.
2. 기존 캠페인을 보존하고 별도 새 프로젝트를 권장한다. 새 프로젝트의 키퍼용 소스에 PRIVATE_CANON_sc1997_survival_rebuild_01_r1.md를 등록한다. 기존 비공개 정본/세이브를 이 캠페인과 섞지 않는다. 범인 정체를 읽고 싶지 않으면 직접 문서를 열지 않고 등록만 한다.
3. MANIFEST.json도 해시 대조용으로 첨부한다. START_NEW_CAMPAIGN.md의 구분선 아래 시작 입력을 새 채팅에 붙인다. 일반 START_GAME 대신 이 설계 전용 입력을 사용한다. 파일 등록/조회·전체 해시 확인은 실제로 성공했을 때만 성공으로 처리한다.
4. 이 파일들은 시작 전 설계다. 게임 시작/공격/판정/피해/외부 저장은 실행하지 않았다. 실제 플레이 뒤에는 기존07-state의 누적 상태/맥락 보존과 실제 저장 검증을 따른다. 초기 정본 하나만으로 이후 진행을 복원할 수 있다고 간주하지 않는다.

MANIFEST.json은 이 묶음의 파일 바이트를, DESIGN_VALIDATION.json은 정본의 식별/참조·길망·수치 등 오프라인 검사 범위를 기록한다. BRANCH_REVIEW.md는 실제 플레이 로그가 아닌 수동 분기 대조다. validate_private_design.py는 외부 서비스에 접속하지 않고 검사를 재실행한다. design_generation.json은 실제 시작 시드 생성 기록이며 PC 굴림이나 미래 사건 추첨 기록이 아니다.

원본 캠페인 파일은 수정하지 않았다. 같은 기자의 기존 시작 프로필을 새 캠페인의 템플릿으로 재사용했으며 원 캠페인의 현재 상태/성과를 초기화하거나 이전 소모를 새 캠페인에 이월한 것이 아니다.
