"""Local design audit only: no game execution or external storage."""
from pathlib import Path
import hashlib,json,re,datetime

root=Path(__file__).resolve().parent
p=root/'PRIVATE_CANON_sc1997_survival_rebuild_01_r1.md'
s=p.read_text()
sections=re.findall(r'^## ([A-Z][A-Z_]+)$',s,re.M)
required={'CANON_INDEX','WORLD_BASELINE','HIDDEN_TRUTH','WORLD_RULES','NPC_BASELINES','EVIDENCE_BASELINES','LOCATION_BASELINES','DRIVER_BASELINES','ENDING_CONDITIONS','PC_CONNECTIONS'}
assert required<=set(sections) and len(sections)==len(set(sections))
index=s.split('## CANON_INDEX',1)[1].split('\n## ',1)[0]
pattern=r'\b(?:P1|NPC|THR|OBJ|LOC|EVT|SIT)_[A-Z0-9_]+\b'
declared=[x for x in re.findall(pattern,index) if x not in sections]
assert len(declared)==len(set(declared))
body=s.split('## WORLD_BASELINE',1)[1]
used=set(re.findall(pattern,body))-set(sections)
assert used==set(declared),(used-set(declared),set(declared)-used)
defined=set(re.findall(r'^### ((?:NPC|THR|OBJ|EVT|SIT)_[A-Z0-9_]+)$',s,re.M))
defined.update(re.findall(r'^\| `(LOC_[A-Z0-9_]+)` \|',s,re.M))
defined.add('P1_RACHEL_NEW')
assert defined==set(declared),(set(declared)-defined,defined-set(declared))
route_line=next(line for line in s.splitlines() if line.startswith('길망:'))
edges=[]
for chain in route_line.split(';'):
    route=re.findall(r'`(LOC_[A-Z0-9_]+)`',chain)
    edges.extend(zip(route,route[1:]))
nodes={x for x in declared if x.startswith('LOC_')}
seen={'LOC_LOBBY'}
while True:
    before=seen.copy()
    for a,b in edges:
        assert a in nodes and b in nodes
        if a in seen or b in seen:seen.update([a,b])
    if seen==before:break
assert seen==nodes
stats=re.findall(r'STR(\d+) CON(\d+) SIZ(\d+) DEX(\d+) APP(\d+) INT(\d+) POW(\d+) EDU(\d+); HP(\d+)(?:/\d+)? SAN(\d+)(?:/\d+)? MOV(\d+) DB([+-]?\d+) Build([+-]?\d+)',s)
assert len(stats)==7,len(stats)
for row in stats:
    st,co,sz,dx,ap,it,pw,ed,hp,san,mov,db,build=map(int,row)
    assert hp==(co+sz)//10 and san==pw
    assert mov==(9 if dx>=70 else 7 if dx<=40 else 8)
    total=st+sz
    assert 85<=total<=124 and db==0 and build==0
assert sum([45,30,50,45,80,30,80,40])==400
assert 'HP8/8, SAN80/80, MOV8, DB0, Build0' in s
assert datetime.date(1997,10,17).weekday()==4
assert 'game_started=false' in s and 'external_save_verified=false' in s
assert '공통 룰북/공개 저장소/배포 ZIP에 넣지 않는다' in s
assert not re.search('[\u3040-\u30ff\u4e00-\u9fff]',s)
report={'file':p.name,'sections':len(sections),'registered_entities':len(declared),'locations':len(nodes),'connected_route_edges':len(edges),'npc_profiles_checked':len(stats),'gameplay_executed':False,'external_save_verified':False,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(root/'DESIGN_VALIDATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('PASS: private identifiers/sections/references, connected routes, NPC/PC derived stats, calendar and unstarted state; no gameplay run')
