# MCP v2 룰북 배포 식별자

rules_version: `TRPG-RULE-v2+sha256:f591f0b8086b54fb8f801c342d7cb8ebd37357b31e1766da02576990f3ea4cec`

같은 ZIP의 RULESET.json과 같은 배포를 식별합니다. 과거 판본 고정용이 아닙니다.
기존 게임의 확정 사실·상태를 유지하고 이후 진행은 최신 v2 소스를 따릅니다.
실제 캠페인 정본·세이브·인증정보는 포함하지 않습니다.
